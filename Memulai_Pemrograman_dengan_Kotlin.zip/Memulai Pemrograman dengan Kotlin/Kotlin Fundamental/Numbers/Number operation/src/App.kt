fun main() {
    val numberOne = 1
    val numberTwo = 2

    print(numberOne + numberTwo)

    print(numberOne / numberTwo)

    println(5 + 4 * 4)

    println((5 + 4) * 4)

}