fun main() {
    val text: String? = null

    //val textLength = text.length // compile time error

    if (text != null){
        val textLength = text.length // ready to go
    }
}