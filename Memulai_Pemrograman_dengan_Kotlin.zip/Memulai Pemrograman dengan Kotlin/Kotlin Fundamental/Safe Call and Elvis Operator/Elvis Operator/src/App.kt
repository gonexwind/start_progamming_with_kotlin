fun main() {
    val text: String? = null
    val textLength = text?.length ?: 7
}